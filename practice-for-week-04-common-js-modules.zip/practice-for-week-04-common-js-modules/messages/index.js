const message1 = "You are looking very spudly today!";
const message2 = "There's a good deal on mattresses tomorrow.";
const message3 = "Do you like to do things in unnecessarily complicated ways?";

module.exports = {msg1: message1, msg2: message2, msg3: message3}
